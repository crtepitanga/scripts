#!/bin/bash
CHROME_DIR="/opt/google/chrome"
CHROME_BIN="$CHROME_DIR/google-chrome"
RESOURCES_PAK="$CHROME_DIR/resources.pak"
BACKUP_DIR="/opt/disable_google_image_search/backups"
HASH_FILE="$BACKUP_DIR/last_hash.txt"
STRING_ORIGINAL="Pesquisar imagem com Google"

if [ "$(id -u)" -ne 0 ]; then
  echo "⚠️ Execute como root"
  exit 1
fi

if [ ! -f "$CHROME_BIN" ] || [ ! -f "$RESOURCES_PAK" ]; then
  echo "❌ Chrome ou resources.pak não encontrados!"
  exit 1
fi

mkdir -p "$BACKUP_DIR"

HASH_CURRENT=$(sha256sum "$RESOURCES_PAK" | awk '{print $1}')
HASH_LAST=""
[ -f "$HASH_FILE" ] && HASH_LAST=$(cat "$HASH_FILE")

if [ "$HASH_CURRENT" == "$HASH_LAST" ]; then
  echo "✅ Resources.pak já patchado. Nada a fazer."
  exit 0
fi

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
cp "$RESOURCES_PAK" "$BACKUP_DIR/resources_$TIMESTAMP.pak"
echo "📦 Backup criado: $BACKUP_DIR/resources_$TIMESTAMP.pak"

LEN=${#STRING_ORIGINAL}
REPLACEMENT=$(printf '%*s' "$LEN")
sed -i "s/$STRING_ORIGINAL/$REPLACEMENT/g" "$RESOURCES_PAK"

HASH_NEW=$(sha256sum "$RESOURCES_PAK" | awk '{print $1}')
echo "$HASH_NEW" > "$HASH_FILE"

if strings "$RESOURCES_PAK" | grep -q "$STRING_ORIGINAL"; then
  echo "❌ Patch não aplicado corretamente."
else
  echo "✅ Patch aplicado com sucesso!"
fi
